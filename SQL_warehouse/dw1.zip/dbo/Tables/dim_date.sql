CREATE TABLE [dbo].[dim_date] (

	[date_key] bigint NULL, 
	[order_time] datetime2(6) NULL, 
	[order_hour] int NULL, 
	[order_day] int NULL, 
	[order_month] int NULL, 
	[order_year] int NULL
);