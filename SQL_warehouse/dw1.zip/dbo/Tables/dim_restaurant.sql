CREATE TABLE [dbo].[dim_restaurant] (

	[restaurant_key] bigint NULL, 
	[restaurant_name] varchar(8000) NULL, 
	[cuisine_type] varchar(8000) NULL
);