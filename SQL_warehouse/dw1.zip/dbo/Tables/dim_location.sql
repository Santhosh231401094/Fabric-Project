CREATE TABLE [dbo].[dim_location] (

	[location_key] bigint NULL, 
	[area_name] varchar(8000) NULL, 
	[city] varchar(8000) NULL
);