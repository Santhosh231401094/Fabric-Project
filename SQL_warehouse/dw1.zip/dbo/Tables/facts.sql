CREATE TABLE [dbo].[facts] (

	[order_id] varchar(8000) NULL, 
	[restaurant_key] bigint NULL, 
	[location_key] bigint NULL, 
	[date_key] bigint NULL, 
	[total_amount] float NULL, 
	[ordered_qty] int NULL, 
	[delivery_time] datetime2(6) NULL, 
	[distance_km] float NULL, 
	[rating_numeric] real NULL, 
	[book_table] varchar(8000) NULL, 
	[online_order] varchar(8000) NULL
);